// Posts.js
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchPosts, deletePost } from './actions/actions';
import { Link } from 'react-router-dom';

const Posts = () => {
    const dispatch = useDispatch();
    const posts = useSelector(state => state.posts);
  
    useEffect(() => {
      dispatch(fetchPosts());
    }, [dispatch]);
  
    const removePost = (id) => {
      dispatch(deletePost(id));
    };
  
    return (
      <div>
        <h2>Posts</h2>
        <ul>
          {posts.map(post => (
            <li key={post.id}>
              {post.title} - {post.body}
              <button onClick={() => removePost(post.id)}>Delete</button>
              <Link to={`/edit/${post.id}`}>Edit</Link>
              <Link to={`/posts/${post.id}`}>View</Link>
            </li>
          ))}
        </ul>
      </div>
    );
  };
  
  export default Posts; 
  

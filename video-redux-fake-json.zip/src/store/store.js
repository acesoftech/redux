// store.js
import { createStore, applyMiddleware } from 'redux';
import {thunk} from 'redux-thunk';
import postsReducer from '../reducers/reducers';

const store = createStore(postsReducer, applyMiddleware(thunk));
//console.log('STORE',store);
export default store;
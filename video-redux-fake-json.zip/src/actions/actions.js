import axios from "axios";
export const FETCH_POSTS = 'FETCH_POSTS';
export const CREATE_POST = 'CREATE_POST';
export const UPDATE_POST = 'UPDATE_POST';
export const DELETE_POST = 'DELETE_POST';
export const FETCH_SINGLE_POST = 'FETCH_SINGLE_POST';



export const createPost = (postData) => async dispatch => {
  try {
    const response = await axios.post('http://localhost:5000/posts', postData);
    dispatch({ type: CREATE_POST, payload: response.data });
  } catch (error) {
    console.error(error);
  }
};


export const fetchPosts = () => async dispatch => {
    try {
      const response = await axios.get('http://localhost:5000/posts');
    //  console.log('AA',response);

      dispatch({ type: FETCH_POSTS, payload: response.data });
      // this sends the data to store 
      // dispatch is a redux function which is used to send actions to store
    } catch (error) {
      console.error(error);
    }
  };

  export const deletePost = (id) => async dispatch => {
    try {
      await axios.delete(`http://localhost:5000/posts/${id}`);
      dispatch({ type: DELETE_POST, payload: id });
    } catch (error) {
      console.error(error);
    }
  };
  

  export const fetchSinglePost = (id) => async dispatch => {
    try {
      const response = await axios.get(`http://localhost:5000/posts/${id}`);
    
    //  console.log('JJJ',response);

      dispatch({ type: FETCH_SINGLE_POST, payload: response.data });
    } catch (error) {
      console.error(error);
    }
  };

  export const updatePost = (id, updatedData) => async dispatch => {
    try {
      const response = await axios.put(`http://localhost:5000/posts/${id}`, updatedData);
      dispatch({ type: UPDATE_POST, payload: response.data });
    } catch (error) {
      console.error(error);
    }
  };
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { fetchSinglePost, updatePost } from './postsSlice'; // Adjusted import

const EditPost = () => {
  const { id } = useParams();
  const [formData, setFormData] = useState({ title: '', body: '' });
  const dispatch = useDispatch();
  const post = useSelector(state => state.posts.singlePost); // Updated state selector
  
  console.log('KK', post);

  useEffect(() => {
    dispatch(fetchSinglePost(id)); // Ensure fetchSinglePost action is dispatched
  }, [dispatch, id]);

  useEffect(() => {
    if (post) {
      setFormData({ title: post.title, body: post.body });
    }
  }, [post]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(updatePost({ id, updatedData: formData })); // Pass id and formData to updatePost
  };

  if (!post) {
    return <div>Loading...</div>;
  }

  return (
    <form onSubmit={handleSubmit}>
      <input 
        type="text" 
        name="title" 
        value={formData.title} 
        onChange={handleChange} 
        placeholder="Enter title" 
      />
      <textarea 
        name="body" 
        value={formData.body} 
        onChange={handleChange} 
        placeholder="Enter body" 
      />
      <button type="submit">Update Post</button>
    </form>
  );
};

export default EditPost;

import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { fetchSinglePost } from './postsSlice'; // Adjusted import

const ViewPost = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const post = useSelector(state => state.posts.singlePost); // Updated state selector

  useEffect(() => {
    dispatch(fetchSinglePost(id));
  }, [dispatch, id]);

  return (
    <div>
      {post ? (
        <div>
          <h2>{post.title}</h2>
          <p>{post.body}</p>
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default ViewPost;

import logo from './logo.svg';
import './App.css';
import { Provider } from 'react-redux';
import store from './store/store'
import Posts from './Posts';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import ViewPost from './ViewPost';
import EditPost from './EditPost';
import AddPost from './AddPost';

function App() {
  return(
  <Provider store={store}>
  <Router>
    <div>
    
      <Routes>
        <Route path="/" element={<Posts />} />
        <Route path="/add" element={<AddPost />} />
        <Route path="/posts/:id" element={<ViewPost />} />
        <Route path="/edit/:id" element={<EditPost />} />
      </Routes>
    </div>
  </Router>
</Provider>
  )
}

export default App;

import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { createPost } from './postsSlice'; // Adjusted import

const AddPost = () => {
  const dispatch = useDispatch();
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  const handleFormSubmit = (e) => {
    e.preventDefault();
    dispatch(createPost({ title, body })).then(() => {
      setTitle('');
      setBody('');
      setIsSuccess(true);
      // Hide the success message after 3 seconds
      setTimeout(() => {
        setIsSuccess(false);
      }, 3000);
    });
  };

  return (
    <div>
      <h2>Add New Post</h2>
      {isSuccess && <p style={{ color: 'green' }}>Successfully added!</p>}
      <form onSubmit={handleFormSubmit}>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Enter title"
        />
        <textarea
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder="Enter body"
        ></textarea>
        <button type="submit">Add Post</button>
      </form>
    </div>
  );
};

export default AddPost;

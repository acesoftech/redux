// Posts.js
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchPosts, deletePost } from './postsSlice'; // Import from postsSlice.js
import { Link } from 'react-router-dom';

const Posts = () => {
  const dispatch = useDispatch();
  const { posts, status, error } = useSelector(state => state.posts);
  
  useEffect(() => {
    if (status === 'idle') {
      dispatch(fetchPosts());
    }
  }, [dispatch, status]);
  
  const removePost = (id) => {
    dispatch(deletePost(id));
  };

  return (
    <div>
      <h2>Posts</h2>
      {status === 'loading' && <div>Loading...</div>}
      {status === 'failed' && <div>Error: {error}</div>}
      <ul>
        {posts.map(post => (
          <li key={post.id}>
            {post.title} - {post.body}
            <button onClick={() => removePost(post.id)}>Delete</button>
            <Link to={`/edit/${post.id}`}>Edit</Link>
            <Link to={`/posts/${post.id}`}>View</Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Posts;

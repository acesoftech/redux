
// actions.js
import { createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

export const fetchPosts = createAsyncThunk('posts/fetchPosts', async () => {
  const response = await axios.get('http://localhost:5001/posts');
  return response.data;
});

export const createPost = createAsyncThunk('posts/createPost', async (postData) => {
  const response = await axios.post('http://localhost:5001/posts', postData);
  return response.data;
});

export const deletePost = createAsyncThunk('posts/deletePost', async (id) => {
  await axios.delete(`http://localhost:5001/posts/${id}`);
  return id;
});

export const fetchSinglePost = createAsyncThunk('posts/fetchSinglePost', async (id) => {
  const response = await axios.get(`http://localhost:5001/posts/${id}`);
  return response.data;
});

export const updatePost = createAsyncThunk('posts/updatePost', async ({ id, updatedData }) => {
  const response = await axios.put(`http://localhost:5001/posts/${id}`, updatedData);
  return response.data;
});

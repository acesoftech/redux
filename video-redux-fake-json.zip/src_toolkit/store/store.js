// store.js
import { configureStore } from '@reduxjs/toolkit';
import postsSlice from '../postsSlice' // Assuming postsSlice.js is in the same directory

const store = configureStore({
  reducer: {
    posts: postsSlice,
  },
});

//console.log('Store',store);
export default store;
